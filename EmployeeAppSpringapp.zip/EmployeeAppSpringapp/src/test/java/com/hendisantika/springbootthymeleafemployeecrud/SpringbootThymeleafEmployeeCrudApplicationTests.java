package com.hendisantika.springbootthymeleafemployeecrud;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootThymeleafEmployeeCrudApplicationTests {

    @Test
    void contextLoads() {
    }

}
