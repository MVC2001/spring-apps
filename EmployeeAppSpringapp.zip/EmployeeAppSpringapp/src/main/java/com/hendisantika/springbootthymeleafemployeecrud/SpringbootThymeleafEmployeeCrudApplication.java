package com.hendisantika.springbootthymeleafemployeecrud;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootThymeleafEmployeeCrudApplication {

    public static void main(String[] args) {
        SpringApplication.run(SpringbootThymeleafEmployeeCrudApplication.class, args);
    }

}
