package com.example.tuitioncenterApplication;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TuitioncenterApplication {

	public static void main(String[] args) {
		SpringApplication.run(TuitioncenterApplication.class, args);
	}

}
